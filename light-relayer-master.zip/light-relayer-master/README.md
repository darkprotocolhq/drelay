# light-relayer
- duplicate .env.example, rename to .env and fill with your sig key
- run node index.js to start the express server
- the (currently http) server listens to rpc calls at the specified port (default: 3000] 

- [x] add redis/queue
- [x] add snarkjs proof verification
- [x] enable https
- [ ] typescript
- [ ] add transaction simulation