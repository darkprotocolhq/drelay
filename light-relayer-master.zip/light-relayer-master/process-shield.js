// @ts-check
require("dotenv").config();
const solana = require("@solana/web3.js");
const { authenticate } = require("./auth");
const { U64 } = require("n64");
const { getLock } = require("./locked");
const {
  sendSignedTransaction,
  recoverAndSignOfflineTransactions,
  recoverAndSignOfflineTransaction,
} = require("./send");
const { PRIVATE_KEY, NONCE_ACCOUNT_OWNER, MERKLE_TREE_PDA_PUBKEY } =
  process.env;

const decodedPrivkey = (privkeyBytes) => {
  const decodedPrivkey = new Uint8Array(64);
  privkeyBytes
    .split(",")
    .map((b, index) => (decodedPrivkey[index] = parseInt(b)));
  return decodedPrivkey;
};
/// Set signer
const signerPrivkey = decodedPrivkey(PRIVATE_KEY);
var signerKeypair = solana.Keypair.fromSecretKey(signerPrivkey);
const signerPubkey = signerKeypair.publicKey;
console.log("signerPubkey: ", signerPubkey.toBase58());
// Set authority signer
const nonceAuthorityPrivkey = decodedPrivkey(NONCE_ACCOUNT_OWNER);
var nonceAuthorityKeypair = solana.Keypair.fromSecretKey(nonceAuthorityPrivkey);
const nonceAuthorityPubkey = nonceAuthorityKeypair.publicKey;

/// Set Connection
var connection;

async function getNodeConnection() {
  connection = await authenticate();
  console.log("Connection to cluster established");
}

async function processShield(job) {
  try {
    console.log("entered processShield0");
    await getNodeConnection();
    const { txPool, txLast, txPoolMirror } = job.data;
    console.log("entered processShield1");

    console.time("sig 1");
    let txPoolRecovered = recoverAndSignOfflineTransactions({
      transactionsAndFeePayerSignatures: txPool,
      nonceAuthorityKeypair: nonceAuthorityKeypair,
    });

    // console.log("TXPOOLMIRROR hashed", txPoolMirror);
    let mirrorPoolRecoveredRaw = recoverAndSignOfflineTransactions({
      transactionsAndFeePayerSignatures: txPoolMirror,
      nonceAuthorityKeypair: nonceAuthorityKeypair,
    });
    // TODO - replace 25 with dynamic value
    let mirrorPoolRecovered = mirrorPoolRecoveredRaw.filter(
      (tx) => tx.instructions.length > 25
    );
    // console.log("mirrorPoolRecovered", mirrorPoolRecovered);
    // find the recovered tx with 15 ix
    let mirrorPoolRecovered15 = mirrorPoolRecoveredRaw.filter(
      (tx) => tx.instructions.length < 25
    )[0];
    // console.log("mirrorPoolRecovered15", mirrorPoolRecovered15);

    console.timeEnd("sig 1");
    console.log("entered processShield2");

    console.time("send 1");
    if (txPoolRecovered) {
      try {
        await Promise.all(
          txPoolRecovered.map((signedTransaction, i) =>
            sendSignedTransaction({
              signedTransaction,
              connection,
              i,
              id: job.id,
            })
          )
        );
      } catch (err) {
        console.log(`failed bc locked! job: ${job.id}`);
        console.log("TXPOOLMIRROR hashed", txPoolMirror.length);
        console.log("TXPOOL hashed", txPool.length);
        // try {
        //   console.log(
        //     "tmp account should be index 1?",
        //     mirrorPoolRecovered[0].instructions[0].keys[1].toBase58()
        //   );
        // } catch (e) {
        //   console.log(e);
        // }
        // try {
        //   console.log(".", mirrorPoolRecovered[0]);
        // } catch (e) {
        //   console.log(e);
        // }
        // try {
        //   console.log("..", mirrorPoolRecovered[0].instructions[0]);
        // } catch (e) {
        //   console.log(e);
        // }
        console.log("verificationPda", job.data.verificationPda);

        let { txArrayIndex } = await getLock({
          merkleTreePubkey: new solana.PublicKey(MERKLE_TREE_PDA_PUBKEY),
          txArray: mirrorPoolRecovered,
          connection,
          id: job.id,
          signerPubkey: job.data.verificationPda,
          // mirrorPoolRecovered[0].instructions[0].keys[2].pubkey.toBase58(),
        });
        console.log("txArrayIndex", txArrayIndex);
        if (!txArrayIndex) {
          return new Error(`getlock: txArrayIndex is ${txArrayIndex}`);
        }

        /// get ix_index from last working tx
        let state_after_30_secs = await connection.getAccountInfo(
          new solana.PublicKey(MERKLE_TREE_PDA_PUBKEY)
        );
        let ix_index = Number(U64(state_after_30_secs.data.slice(212, 220)));

        console.log("ixindex..", ix_index);
        console.log(
          "Formula: start slice: ",
          Number(mirrorPoolRecovered.length) - (1484 - ix_index) / 53
        );
        console.log("slice end: ", mirrorPoolRecovered.length);
        let mirrorPool = mirrorPoolRecovered.slice(
          Number(mirrorPoolRecovered.length) - 6
          // Number(mirrorPoolRecovered.length) - (1484 - ix_index) / 53
        );
        console.log("mirrorpool", mirrorPool.length);
        console.log("job.id", job.id);

        try {
          await Promise.all(
            mirrorPool.map((signedTransaction, i) =>
              sendSignedTransaction({
                signedTransaction,
                connection,
                i,
                id: job.id,
              })
            )
          );
          console.log(`done sending mirror pool...${job.id}`);
        } catch (e) {
          console.log(
            `failed mirror pool! (expect last tx now....) job: ${job.id}, e -${e}`
          );
        }
        try {
          await sendSignedTransaction({
            signedTransaction: mirrorPoolRecovered15,
            connection,
            i: mirrorPoolRecoveredRaw.length - 1,
            id: job.id,
          });
        } catch {
          console.log("cannot execute last 15 ix, skip to last tx");
        }
      }
    } else {
      throw new Error("Unable to sign all Pool transactions");
    }
    console.timeEnd("send 1");

    console.time("sig 2");
    let recoverTx = recoverAndSignOfflineTransaction({
      messageAndFeePayerSignature: txLast,
      nonceAuthorityKeypair: nonceAuthorityKeypair,
    });
    console.time("sig 2");

    console.time("reconnecting");
    await getNodeConnection();
    console.timeEnd("reconnecting");

    console.time("send 2");
    if (recoverTx) {
      await sendSignedTransaction({
        signedTransaction: recoverTx,
        connection,
        id: job.id,
      });
    } else {
      throw new Error("Unable to sign last transaction.");
    }
    console.timeEnd("send 2");

    console.log("success");
    return true;
  } catch (e) {
    console.log(e);
    // return false => rebuild job.
    return false;
  }
}

module.exports = { processShield };
