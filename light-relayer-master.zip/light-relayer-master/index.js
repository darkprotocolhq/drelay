const IORedis = require("ioredis");
require("dotenv").config();
const express = require("express");
const { Queue, Worker } = require("bullmq");

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const client = require("twilio")(accountSid, authToken);
const { getJobList, sendTwilio, minute } = require("./house-keeper.js");
const nacl = require("tweetnacl");
const newNonce = () => nacl.randomBytes(nacl.box.nonceLength);
const { getToken } = require("./auth.js");
const { version } = require("./package.json");
const { zKey } = require("snarkjs");
const { processShield } = require("./process-shield.js");
const { processUnshield, checkParams } = require("./process-unshield.js");
const { BATCH_ARRAY } = require("./nonce-pubkeys");
var vKey;
const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));
// app.use(express.json());
const sleep = (ms) => new Promise((res) => setTimeout(res, ms));
const DEFAULT_TIMEOUT = 60 * 1000 * 40;

const connection = new IORedis(
  Number(process.env.DB_PORT),
  process.env.HOSTNAME,
  {
    username: "default",
    password: process.env.PASSWORD,
    tls: {},
  }
);

const shieldQueue = new Queue("shielding", { connection }); // Specify Redis connection using object
const unshieldQueue = new Queue("unshielding", { connection }); // Specify Redis connection using object
const burnerQueue = new Queue("burner", { connection }); // append only store
const nonceQueue = new Queue("nonce", { connection }); // append only store
const archivedShieldQueue = new Queue("archivedShielding", { connection }); // append only store
const archivedUnshieldQueue = new Queue("archivedUnshielding", { connection }); // append only store

console.log("Queues activated", burnerQueue);
// Add CORS headers
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

app.get("/", function (req, res) {
  res.send("/relay to relay. v1.0.0");
});

/// On startup, check queues, fill active ones if need be
const batchArray = BATCH_ARRAY;
const lockArray = Array(batchArray.length).fill(0);
// Only on startup
console.log("lockArray: ", lockArray);

/// SCRIPT TO REMOVE
(async () => {
  // let jobs = await nonceQueue.getWaiting();
  // await Promise.all(
  //   jobs.map(async (j, i) => {
  //     let job = await j.remove();
  //     console.log("j rmd?", job);
  //   })
  // );

  // let Job = await nonceQueue.getWaiting();
  // await Promise.all(
  //   Job.map(async (j, i) => {
  //     let job = await j.remove();
  //     console.log("j", job);
  //   })
  // );

  // console.log("SWEN", await nonceQueue.getWaiting());
  //
  /// SCRIPT TO ADD
  // await Promise.all(
  //   lockArray.map(async (lock, i) => {
  //     let job = await nonceQueue.add(String(i), {
  //       index: i,
  //       timeStamp: Date.now(),
  //     });
  //     console.log("j", job);
  //   })
  // );
  console.log(
    "waitign jobs nonceQueue.getWaiting \n",
    (await nonceQueue.getWaiting()).length
  );
  console.log(
    "active jobs nonceQueue.getActive \n",
    (await nonceQueue.getActive()).length
  );
})();

const nonceWorker = new Worker("nonce", null, {
  lockDuration: 1200000,
  connection: connection,
  concurrency: 1,
});

app.get("/nonces", async function (req, res) {
  const token = String(newNonce());
  const { nonceIndex, batch, jobId } = await getNonceJobData(token, res);

  if (!batch || !nonceIndex || !jobId) {
    console.log("failed to get job: i:", nonceIndex);
    return res.status(514).send("failed to get nonces");
  }
  return res
    .status(200)
    .json({ nonce_batch_and_index: { batch, index: nonceIndex, token, jobId } })
    .send();
});

function toUintArray(value) {
  let buffer;

  if (typeof value !== Buffer) {
    buffer = Buffer.from(Object.values(value));
  } else if (typeof value === Uint8Array) {
    buffer = value;
    return value;
  } else {
    buffer = Buffer.from(value);
  }
  let asArr = new Uint8Array(buffer.length);
  asArr.set(buffer);
  return asArr;
}

async function addShieldJob(req, nonce) {
  let job = await shieldQueue.add(nonce, {
    txPool: req.body.txPool,
    txLast: req.body.txLast,
    txPoolMirror: req.body.txPoolMirror,
    hashedPrivkey: toUintArray(req.body.hashedPrivkey),
    hashedPubkey: toUintArray(req.body.hashedPubkey),
    nonce: toUintArray(req.body.nonce),
    throwawayPubkey: toUintArray(req.body.throwawayPubkey),
    amount: req.body.amount,
    nonceIndex: req.body.nonceIndex,
    token: req.body.token,
    jobId: req.body.jobId,
    nonceIndexMirror: req.body.nonceIndexMirror,
    tokenMirror: req.body.tokenMirror,
    jobIdMirror: req.body.jobIdMirror,
    verificationPda: req.body.verificationPda,
  });
  console.log("Added job shield:", job);
  return job;
}

async function addUnshieldJob(
  req,
  nonce,
  nonceIndex,
  token,
  batch,
  jobId,
  jobIdMirror,
  batchMirror,
  nonceIndexMirror,
  tokenMirror
) {
  let job = await unshieldQueue.add(nonce, {
    input: req.body.input,
    proof: req.body.proof,
    amount: req.body.amount,
    extData: Array.from(toUintArray(req.body.extData)),
    action: req.body.action,
    hashedPubkey: Array.from(toUintArray(req.body.hashedPubkey)),
    nonce: Array.from(toUintArray(req.body.nonce)),
    throwawayPubkey: Array.from(toUintArray(req.body.throwawayPubkey)),
    nonceIndex,
    token,
    batch,
    jobId,
    jobIdMirror,
    batchMirror,
    nonceIndexMirror,
    tokenMirror,
  });
  console.log("Added job unshield :", job);
  return job;
}

async function addBurnerJob(req, nonce) {
  let job = await burnerQueue.add(nonce, {
    hashedPrivkey: toUintArray(req.body.hashedPrivkey),
    nonce: toUintArray(req.body.nonce),
    throwawayPubkey: toUintArray(req.body.throwawayPubkey),
  });
  return job;
}

app.post("/w-unshield", async function (req, res) {
  // check validity of proof data
  try {
    await checkParams(req, vKey);
  } catch (e) {
    return res.status(500).json(false).send();
  }

  // add unshield job to redis
  let nonce = String(newNonce());
  let token = String(newNonce());
  const { nonceIndex, batch, jobId } = await getNonceJobData(token, res);

  let tokenMirror = String(newNonce());
  const {
    nonceIndex: nonceIndexMirror,
    batch: batchMirror,
    jobId: jobIdMirror,
  } = await getNonceJobData(tokenMirror, res);

  try {
    let unshieldJob = await addUnshieldJob(
      req,
      nonce,
      nonceIndex,
      token,
      batch,
      jobId,
      jobIdMirror,
      batchMirror,
      nonceIndexMirror,
      tokenMirror
    );
    console.log("added /unshield job", unshieldJob);
    // let state;
    // let i = 0;
    // let maxSteps = 600;
    // let sleepTime = 1000;
    // while (i < maxSteps) {
    //   await sleep(sleepTime);
    //   state = await unshieldJob.getState();
    //   if (state === "completed" || state === "failed" || state === "unknown") {
    //     i = 600;
    //     console.log("Unshield final state: ", state);
    //     if (state === "failed") {
    //       return res.status(500).json(false).send();
    //     } else {
    //       return res.status(200).json(true).send();
    //     }
    //   } else {
    //     console.log(
    //       ` Job: ${unshieldJob.id} state: ${state} sleep (${sleepTime}) step: ${i} / ${maxSteps}`
    //     );
    //     i++;
    //   }
    // }

    const returnData = {
      recipient: req.body.recipient,
      amount: req.body.amount,
    };
    console.log("return data:", returnData);
    return res.status(200).json(returnData).send();
  } catch (e) {
    console.log(e);
    return res.status(555).json(false).send();
  }
});

app.post("/relayunshield", async function (req, res) {
  // add unshield job to redis
  let nonce = String(newNonce());
  let token = String(newNonce());
  const { nonceIndex, batch, jobId } = await getNonceJobData(token, res);

  let tokenMirror = String(newNonce());
  const {
    nonceIndex: nonceIndexMirror,
    batch: batchMirror,
    jobId: jobIdMirror,
  } = await getNonceJobData(tokenMirror, res);

  try {
    let unshieldJob = await addUnshieldJob(
      req,
      nonce,
      nonceIndex,
      token,
      batch,
      jobId,
      jobIdMirror,
      batchMirror,
      nonceIndexMirror,
      tokenMirror
    );
    console.log("added /unshield job", unshieldJob);
    let state;
    let i = 0;
    let maxSteps = 600;
    let sleepTime = 2000;
    while (i < maxSteps) {
      await sleep(sleepTime);
      state = await unshieldJob.getState();
      if (state === "completed" || state === "failed" || state === "unknown") {
        i = 600;
        console.log("Unshield final state: ", state);
        if (state === "failed") {
          return res.status(500).json(false).send();
        } else {
          return res.status(200).json(true).send();
        }
      } else {
        console.log(
          ` Job: ${unshieldJob.id} state: ${state} sleep (${sleepTime}) step: ${i} / ${maxSteps}`
        );
        i++;
      }
    }
    console.log("this should never happen: 20min timeout");
  } catch (e) {
    console.log(e);
    return res.status(555).json(false).send();
  }
});

async function getNonceJobData(token, res) {
  var job = await nonceWorker.getNextJob(token);
  console.log("JOB1", job);
  let retries = 0;
  while (!job.data.index && retries < 5) {
    try {
      await job.moveToFailed(new Error("Closing nonceJob "), token, false);
      console.log("undefined found getting next job");
    } catch (e) {
      console.log("failed to move job: ", e);
    }
    try {
      await job.remove();
    } catch {
      console.log("failed to get next job");
    }
    job = await nonceWorker.getNextJob(token);
    retries++;
  }
  if (!job) {
    return res.status(507).json("High traffic. Please come back later").send();
  }
  let nonceIndex = job.data.index;
  let batch = batchArray[nonceIndex];
  let jobId = job.id;
  return { nonceIndex, batch, jobId };
}

app.post("/relayshield", async function (req, res) {
  let nonce = String(newNonce());

  try {
    let job = await addShieldJob(req, nonce);

    let state;
    let i = 0;
    let maxSteps = 600;
    let sleepTime = 2000;
    while (i < maxSteps) {
      await sleep(sleepTime);
      state = await job.getState();
      console.log("/shield state:", state);
      if (state === "completed" || state === "failed" || state === "unknown") {
        i = 600;
        console.log("Shield final state: ", state);
        if (state === "failed") {
          return res.status(500).json(false).send();
        } else {
          return res.status(200).json(true).send();
        }
      } else {
        console.log(
          ` Job: ${job.id} state: ${state} sleep (${sleepTime}) step: ${i} / ${maxSteps}`
        );
        i++;
      }
    }
    console.log("timeout 20min - this should never happen - shield");
  } catch (e) {
    console.log(e);
    return res.status(555).json(false).send();
  }
});

app.post("/burner", async function (req, res) {
  // add shield job to redis

  let nonce = String(newNonce());

  try {
    let job = await addBurnerJob(req, nonce);
    console.log("added /burner job");

    if (job) {
      res.status(200).json("ok");
    } else {
      res.status(500).json(false);
    }
  } catch (e) {
    console.log(e);
    res.status(500).json(false);
  }
});

app.get("/burner", async function (req, res) {
  var qBurner = burnerQueue;
  try {
    let burner = await qBurner.getWaiting();
    console.log("get /burner");
    res.status(200).json({ burner });
  } catch (e) {
    console.log("error get/burner", e);
    res.status(500).json(false);
  }
});

app.get("/auth", async function (req, res) {
  try {
    let access_token = await getToken();
    // res.send(connection);
    res.status(200).json({ access_token });
  } catch (e) {
    console.log(e);
    res.status(500);
  }
});

app.get("/pending", async function (req, res) {
  var qShield = shieldQueue;
  var qUnshield = unshieldQueue;
  console.log("/pending, qShield");
  try {
    let uwj = await qUnshield.getWaiting();
    let uaj = await qUnshield.getActive();
    let swj = await qShield.getWaiting();
    let saj = await qShield.getActive();

    let pending = [
      uwj.map((job) => ({
        amount: job.data.amount,
        hashedPubkey: toUintArray(job.data.hashedPubkey),
        nonce: toUintArray(job.data.nonce),
        throwawayPubkey: toUintArray(job.data.throwawayPubkey),
        type: "unshield",
      })),
      swj.map((job) => ({
        amount: job.data.amount,
        hashedPubkey: toUintArray(job.data.hashedPubkey),
        hashedPrivkey: toUintArray(job.data.hashedPrivkey),
        nonce: toUintArray(job.data.nonce),
        throwawayPubkey: toUintArray(job.data.throwawayPubkey),
        type: "shield",
        state: "waiting",
        id: job.id,
        // ...job,
      })),
      uaj.map((job) => ({
        amount: job.data.amount,
        hashedPubkey: toUintArray(job.data.hashedPubkey),
        nonce: toUintArray(job.data.nonce),
        throwawayPubkey: toUintArray(job.data.throwawayPubkey),
        type: "unshield",
      })),
      saj.map((job) => ({
        amount: job.data.amount,
        hashedPubkey: toUintArray(job.data.hashedPubkey),
        hashedPrivkey: toUintArray(job.data.hashedPrivkey),
        nonce: toUintArray(job.data.nonce),
        throwawayPubkey: toUintArray(job.data.throwawayPubkey),
        type: "shield",
        state: "active",
        id: job.id,
        // ...job,
      })),
    ].flat();
    console.log("pending jobs:", pending.length);

    res.status(200).json({ pending });
  } catch (e) {
    console.log(e);
    res.status(500).json(false);
  }
});

let port = Number(process.env.PORT) || 8080;

const shieldWorker = new Worker(
  "shielding",
  async (job) => {
    console.log("processing... shieldJob", job.id);
    const result = await processShield(job);
    console.log("shieldJob done result", result);

    if (!result) {
      // let nonce = String(newNonce());
      // return (err) but create new job identical...job
      // unshieldQueue.add(nonce, { ...job.data });
      // console.log("moving to delayer=", job.id);
      // await job.moveToDelayed(Date.now() + 1000);
      // await job.moveToFailed(new Error("failed to process shield.")
      // console.log("moved to delayer=", job);
      throw new Error("failed to process shield.");
    }
    let index = job.data.nonceIndex;
    console.log(
      `queue length before: ${(await nonceQueue.getWaiting()).length}`
    );

    let nonceJob = await nonceQueue.getJob(job.data.jobId);

    console.log("Got nonceJob id:", nonceJob.id);
    try {
      await nonceJob.moveToFailed(
        new Error("Closing nonceJob "),
        job.data.token,
        false
      );
      await nonceJob.remove();
      console.log("removed nonceJob");
      console.log(`queue length: ${(await nonceQueue.getWaiting()).length}`);
      let nonce = String(newNonce());
      // Open same index up again
      await nonceQueue.add(nonce, {
        index: index,
        timeStamp: Date.now(),
      });
      console.log("added nonceJob again");
      console.log(`queue length: ${(await nonceQueue.getWaiting()).length}`);
    } catch (e) {
      console.log("couldnt move/remove job (1)-- not adding more");
    }

    /// /// /// for mirror batch as well
    // destroy the job with token, then create a new one.
    let indexMirror = job.data.nonceIndexMirror;
    console.log(
      `queue length before: ${(await nonceQueue.getWaiting()).length}`
    );

    let nonceMirrorJob = await nonceQueue.getJob(job.data.jobIdMirror);
    console.log(
      `queue length after: ${(await nonceQueue.getWaiting()).length}`
    );
    console.log("Got nonceJobMirror id:", nonceMirrorJob.id);
    try {
      await nonceMirrorJob.moveToFailed(
        new Error("Closing nonceJob "),
        job.data.tokenMirror,
        false
      );
      await nonceMirrorJob.remove();

      console.log("removed nonceJobMirror");
      console.log(`queue length: ${(await nonceQueue.getWaiting()).length}`);
      let nonceMirror = String(newNonce());
      // Open same index up again
      await nonceQueue.add(nonceMirror, {
        index: indexMirror,
        timeStamp: Date.now(),
      });
      console.log("added nonceJob again");
      console.log(`queue length: ${(await nonceQueue.getWaiting()).length}`);
    } catch (e) {
      console.log("couldnt move/remove job (2)-- not adding more");
    }

    return true;
  },
  { connection: connection, concurrency: 7 }
);

const unshieldWorker = new Worker(
  "unshielding",
  async (job) => {
    console.log("processing... unshieldJob", job.id);
    const result = await processUnshield(
      job,
      vKey,
      job.data.batch,
      job.data.batchMirror
    );
    console.log("result", result);
    if (!result) {
      // let nonce = String(newNonce());
      // return (err) but create new job identical...job
      // unshieldQueue.add(nonce, { ...job.data });
      console.log("moving to delayer=", job.id);
      await job.moveToDelayed(Date.now() + 1000);
      console.log("moved to delayer=", job);
      return true;
    }

    let index = job.data.nonceIndex;
    let nonceJob = await nonceQueue.getJob(job.data.jobId);
    // sometimes jobs don't have an index

    console.log(`queue length: ${(await nonceQueue.getWaiting()).length}`);
    console.log("Got nonceJob id:", nonceJob.id);
    try {
      await nonceJob.moveToFailed(
        new Error("Closing nonceJob "),
        job.data.token,
        false
      );
      await nonceJob.remove();

      console.log("removed nonceJob");
      console.log(`queue length: ${(await nonceQueue.getWaiting()).length}`);

      let nonce = String(newNonce());
      // Open same index up again

      await nonceQueue.add(nonce, {
        index: index,
        timeStamp: Date.now(),
      });
      console.log("added nonceJob again");
      console.log(`queue length: ${(await nonceQueue.getWaiting()).length}`);
    } catch (e) {
      console.log("couldnt move/remove job (1)-- not adding more");
    }

    //     ///////

    let indexMirror = job.data.nonceIndexMirror;
    let nonceMirrorJob = await nonceQueue.getJob(job.data.jobIdMirror);
    try {
      await nonceMirrorJob.moveToFailed(
        new Error("Closing nonceJob "),
        job.data.tokenMirror,
        false
      );
      await nonceMirrorJob.remove();
      console.log("removed nonceJobMirror");
      console.log(`queue length: ${(await nonceQueue.getWaiting()).length}`);
      let nonceMirror = String(newNonce());
      // Open same index up again
      await nonceQueue.add(nonceMirror, {
        index: indexMirror,
        timeStamp: Date.now(),
      });
      console.log("added nonceJob again");
      console.log(`queue length: ${(await nonceQueue.getWaiting()).length}`);
    } catch (e) {
      console.log("couldnt move/remove job (2)-- not adding more");
    }

    return true;
  },
  { connection: connection, concurrency: 7 }
);

shieldWorker.on("completed", async (job) => {
  console.log(`${job.id} has completed!`);
});

shieldWorker.on("failed", async (job, err) => {
  let duration = Date.now() - job.timestamp;
  let message = `${job.id} failed (${err.message}) after ${duration / minute}s`;
  console.log(message);
  await sendTwilio(message);
});
unshieldWorker.on("completed", async (job) => {
  console.log(`${job.id} has completed!`);
});

unshieldWorker.on("failed", async (job, err) => {
  let duration = Date.now() - job.timestamp;
  let message = `${job.id} failed (${err.message}) after ${duration / minute}s`;
  console.log(message);
  await sendTwilio(message);
});

app.listen(port, async () => {
  console.log(`Relayer ${version} started on port ${port}`);
  vKey = await zKey.exportVerificationKey(`transaction2.zkey`);

  console.log("rpc:", process.env.RPC_URL);
});

(async () => {
  let waiting = await unshieldQueue.getWaiting();
  console.log("waiting unshield", waiting);

  let active = await unshieldQueue.getActive();
  console.log("active unshield", active);
  waiting = await shieldQueue.getWaiting();
  console.log("waiting shield", waiting);

  active = await shieldQueue.getActive();
  console.log("active shield", active);
})();

async function moveJobs(job, archivedShieldQueue, archivedUnshieldQueue) {
  if (Date.now() - job.timestamp >= DEFAULT_TIMEOUT) {
    try {
      let nonce = newNonce();
      // move to archived queue
      if (job.data.txPool) {
        await archivedShieldQueue.add(nonce, job.data);
      } else if (job.data.proof) {
        await archivedUnshieldQueue.add(nonce, job.data);
      }
    } catch (e) {
      console.log("e cannot archieve");
    }
  }
}

async function wipeNonceJobs(job, nonceQueue) {
  console.log("job", job);
  console.log("TIME NOW:", Date.now());
  console.log("TIMESTAMP:", job.timestamp);
  console.log("TIME DIFF:", Date.now() - job.timestamp);

  if (Date.now() - job.timestamp >= DEFAULT_TIMEOUT) {
    //job.data.startTime
    if (job.data.nonceIndex) {
      let nonceJob;
      try {
        nonceJob = await nonceQueue.getJob(job.data.jobId);
        await nonceJob.moveToFailed("timeout nonce", job.data.token);
      } catch (e) {
        console.log(e);
      }
      if (nonceJob) {
        await nonceJob.remove();
        console.log("rmd nonceJob (1)");
      }
    }
    if (job.data.nonceIndexMirror) {
      let nonceMirrorJob;
      try {
        nonceMirrorJob = await nonceQueue.getJob(job.data.jobIdMirror);
        await nonceMirrorJob.moveToFailed(
          "timeout nonce",
          job.data.tokenMirror
        );
      } catch (e) {
        console.log(e);
      }
      if (nonceMirrorJob) {
        await nonceMirrorJob.remove();
        console.log("rmd nonceMirrorJob (2)");
      }
    }

    console.log("timeout 10m - removing job", job.id);
    try {
      await job.moveToFailed("timeout job");
    } catch (e) {
      console.log(e);
    }
    try {
      await job.remove();
    } catch {}
  }
}

(async () => {
  while (1) {
    try {
      let { total: activeJobs } = await getJobList();
      console.log("(waiting+active)jobs count:", activeJobs.length);

      if (activeJobs.length > 0) {
        await Promise.all(
          activeJobs.map((job) =>
            moveJobs(job, archivedShieldQueue, archivedUnshieldQueue)
          )
        );
        await Promise.all(
          activeJobs.map((job) => wipeNonceJobs(job, nonceQueue))
        );
        console.log("housekeeper - waiting...");
      } else {
        console.log("housekeeper - no active jobs found!");
      }
      await sleep(50000);
    } catch (e) {
      console.log(e);
      await sleep(50000);
    }
  }
})();
