//@ts-check
const { U64 } = require("n64");
const solana = require("@solana/web3.js");
const { sendSignedTransaction } = require("./send.js");
const bs58 = require("bs58");

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));
const getUnixTs = () => {
  return new Date().getTime() / 1000;
};
async function getLock({
  merkleTreePubkey,
  txArray,
  connection,
  id,
  timeout = 60000 * 10,
  signerPubkey,
}) {
  // should be entered if a tx fails
  console.log("Merkle tree might be locked.");
  //check that the transaction really failed because of a lock
  let merkle_tree_data = await connection.getAccountInfo(merkleTreePubkey);
  console.log(
    "merkle_tree_data.data.slice(16618,16650): ",
    merkle_tree_data.data.slice(16618, 16650)
  );
  let current_slot = await connection.getSlot();
  console.log(
    "Time locked: ",
    merkle_tree_data.data.slice(16650, 16658),
    "Time now: ",
    current_slot
  );

  let locked = true;
  let txArrayIndex = 0;
  const startTime = getUnixTs();
  //   let timedOut = false;
  // check whether lock still exists
  while (locked && timeout > getUnixTs() - startTime) {
    await sleep(2000);
    console.log(`Checking if lock is still there - job ${id}`);
    merkle_tree_data = await connection.getAccountInfo(merkleTreePubkey);
    current_slot = await connection.getSlot();

    // if lock is released send one tx to take lock

    console.log("== our tmp?", signerPubkey);
    console.log(
      "which tmp pda locked it?",
      new solana.PublicKey(merkle_tree_data.data.slice(16618, 16650)).toBase58()
    );

    if (
      merkle_tree_data.data.slice(16618, 16650) === new Array(32).fill(0) ||
      new solana.PublicKey(
        merkle_tree_data.data.slice(16618, 16650)
      ).toBase58() === signerPubkey
    ) {
      // lock is released or mine
      locked = false;
    } else {
      console.log(
        "current_slot: ",
        current_slot,
        " > ",
        Number(U64(merkle_tree_data.data.slice(16650, 16658))) +
          Number(U64(600))
      );
      if (
        current_slot >
        Number(U64(merkle_tree_data.data.slice(16650, 16658))) +
          Number(U64(600))
      ) {
        locked = false;
        console.log("Merkle tree is locked: ", locked);
      } else {
        locked = true;
        console.log("Merkle tree is locked: ", locked);
      }
    }

    // try to take lock
    if (locked === false) {
      try {
        console.log(
          `${id} getlock - sending tx: ${txArray[
            txArrayIndex
          ].feePayer.toBase58()} - ${bs58.encode(
            txArray[txArrayIndex].signatures[0].signature
          )}`
        );
      } catch {
        console.log("fprnt getlock index", txArrayIndex);
        try {
          console.log("fprnt getlock - sending tx:", txArray[txArrayIndex]);
        } catch (e) {
          console.log("fprnt: used up all backups", e);
        }
      }

      console.log(`${id} INDEX: ${txArrayIndex}`);
      console.log("txArray[txArrayIndex]", txArray[txArrayIndex]);
      console.log("txarray length", txArray.length);
      try {
        let res = await sendSignedTransaction({
          signedTransaction: txArray[txArrayIndex],
          connection,
          // confirmLevel: "processed",
          id: id,
          timeout: 80000,
        });
        locked = false;

        console.log(`${id} claimed lock - signature ${res}`);
      } catch (e) {
        console.log(`getLock failed -job ${id} e: ${e}`);
        locked = true;
      }

      txArrayIndex++;
      console.log("WHILE END");
    }
  }
  if (locked) {
    throw new Error("get lock timed out");
  }
  // return to execute last tx
  return { txArrayIndex };
}

module.exports = { getLock };
