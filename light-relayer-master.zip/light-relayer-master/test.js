const { Queue, Worker } = require("bullmq");
require("dotenv").config();
const IORedis = require("ioredis");
const connection = new IORedis(
  Number(process.env.DB_PORT),
  process.env.HOSTNAME,
  {
    username: "default",
    password: process.env.PASSWORD,
    tls: {},
  }
);
console.log("conf", connection);
const { BATCH_ARRAY } = require("./nonce-pubkeys");

const nonceQueue = new Queue("nonce", { connection }); // append only store

// (async () => {
//   const worker = new Worker("my-queue", null, {
//     connection: connection,
//     concurrency: 1,
//   });

//   let j = await nonceQueue.add("yo", { index: 1 });
//   console.log(j);
//   // Specify a unique token
//   const token = "yo";
//   const job = await worker.getNextJob(token);
//   console.log("job: ", job);
//   let jobId = job.id;
//   let index = job.data.index;

//   let jj = await nonceQueue.getJob(jobId);

//   await jj.moveToFailed("ok", token, false);

//   await jj.remove();

//   let newo = await nonceQueue.add("yo", { index: index });
//   console.log("new:", newo);

//   // Access job.data and do something with the job
//   //   await worker.callProcessJob(job[0], "yo");

//   //   if (1) {
//   //     await job.moveToCompleted("some return value", token);
//   //   } else {
//   //     await job.moveToFailed(new Error("my error message"), token);
//   //   }

//   await worker.close();
// })();
(async () => {})();

const batchArray = BATCH_ARRAY;
const lockArray = Array(batchArray.length).fill(0);
(async () => {
  // await Promise.all(
  //   lockArray.map(async (lock, i) => {
  //     let job = await nonceQueue.add(String(i), {
  //       index: i,
  //       timeStamp: Date.now(),
  //     });
  //     console.log("j", job);
  //   })
  // );
  let jobs = await nonceQueue.getWaiting();

  let ids = jobs.map((j) => (j.data.index ? j.data.index : null));

  let jobs2 = await nonceQueue.getActive();
  // let jobs = await nonceQueue.getFailed();
  console.log(jobs.length);
  console.log(ids);
  console.log(jobs2.length);
})();
