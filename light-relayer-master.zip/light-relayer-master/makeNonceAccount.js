const solana = require("@solana/web3.js");
require("dotenv").config();
const token = require("@solana/spl-token");
var ffjavascript = require("ffjavascript");

const { wtns, groth16, zKey } = require("snarkjs");
const { U64, I64 } = require("n64");
const { authenticate } = require("./auth");
const { unstringifyBigInts, leBuff2int, leInt2Buff, beInt2Buff } =
  ffjavascript.utils;
const { sendSignedTransaction, signTransactions } = require("./send");

const PRIVATE_KEY = process.env.NONCE_ACCOUNT_OWNER;

const decodedPrivkey = (privkeyBytes) => {
  const decodedPrivkey = new Uint8Array(64);
  privkeyBytes
    .split(",")
    .map((b, index) => (decodedPrivkey[index] = parseInt(b)));
  return decodedPrivkey;
};
/// Set signer
const signerPrivkey = decodedPrivkey(PRIVATE_KEY);
var signerKeypair = solana.Keypair.fromSecretKey(signerPrivkey);
const signerPubkey = signerKeypair.publicKey;
console.log("signerPubkey: ", signerPubkey.toBase58());

/// Set Connection

// var connection = new solana.Connection(
//   solana.clusterApiUrl("devnet"),
//   "confirmed"
// );

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

async function makeNonceAccount({ nonceAccount }) {
  let { blockhash } = await connection.getRecentBlockhash("confirmed");

  let tx = new solana.Transaction().add(
    // create nonce account
    solana.SystemProgram.createAccount({
      fromPubkey: signerPubkey,
      newAccountPubkey: nonceAccount.publicKey,
      lamports: await connection.getMinimumBalanceForRentExemption(
        solana.NONCE_ACCOUNT_LENGTH
      ),
      space: solana.NONCE_ACCOUNT_LENGTH,
      programId: solana.SystemProgram.programId,
    }),
    // init nonce account
    solana.SystemProgram.nonceInitialize({
      noncePubkey: nonceAccount.publicKey, // nonce account pubkey
      authorizedPubkey: signerPubkey, // nonce account authority (for advance and close)
    })
  );
  tx.feePayer = signerPubkey;
  tx.recentBlockhash = blockhash;
  tx.sign(...[signerKeypair, nonceAccount]);

  try {
    let txHash = await sendSignedTransaction({
      signedTransaction: tx,
      connection,
    });
    console.log(
      `confirmed: ${await connection.confirmTransaction(txHash, "confirmed")}`
    );
  } catch (e) {
    console.log("FAIL", e);
  }
  // const txHash = await connection.sendTransaction(tx, [
  //   signerKeypair,
  //   nonceAccount,
  // ]);
  // console.log("txHash", txHash);
}

const BATCHES = 50;
fs = require("fs");

// for each batch: get multimpleAccountsInfo : ? null -> sign+sendSigned transactions
async function idk(p, pubkey, blockhash) {
  let tx = new solana.Transaction().add(
    solana.SystemProgram.nonceWithdraw({
      noncePubkey: pubkey,
      authorizedPubkey: signerPubkey,
      toPubkey: signerPubkey,
      lamports: await connection.getBalance(pubkey),
    })
  );
  tx.feePayer = signerPubkey;
  tx.recentBlockhash = blockhash;
  tx.sign(...[signerKeypair]);
  try {
    await sendSignedTransaction({ signedTransaction: tx, connection });
  } catch (e) {
    console.log("NO EXISTE:", e);
  }

  // let info = await connection.getAccountInfo(new solana.PublicKey(p));
  // console.log(info);
  // if (info === null) {
  //   // sign and send
  //   console.log("NOT EXISTENT...CREATING...");
  //   let tx = new solana.Transaction();
  //   tx.add(
  //     // create nonce account
  //     solana.SystemProgram.createAccount({
  //       fromPubkey: signerPubkey,
  //       newAccountPubkey: pubkey,
  //       lamports: await connection.getMinimumBalanceForRentExemption(
  //         solana.NONCE_ACCOUNT_LENGTH
  //       ),
  //       space: solana.NONCE_ACCOUNT_LENGTH,
  //       programId: solana.SystemProgram.programId,
  //     }),
  //     // init nonce account
  //     solana.SystemProgram.nonceInitialize({
  //       noncePubkey: pubkey, // nonce account pubkey
  //       authorizedPubkey: signerPubkey, // nonce account authority (for advance and close)
  //     })
  //   );
  //   tx.feePayer = signerPubkey;
  //   tx.recentBlockhash = blockhash;
  //   tx.sign(...[signerKeypair]);
  //   await sendSignedTransaction({ signedTransaction: tx, connection });
  //   // sign
  //   // signTransaction()
  // } else {
  //   console.log("EXISTS...");
  // }
  return;
}

// (async () => {
//   connection = await authenticate();
//   // let file;
//   fs.readFile("./noncePubkeys1.txt", "utf8", async (err, data) => {
//     if (err) {
//       console.error(err);
//       return;
//     }
//     // console.log(data);
//     // file = data;
//     // console.log(file);
//     let file = Array.from(JSON.parse(data));
//     console.log(typeof file, file);
//     for (var i in file) {
//       console.log(file[i]);
//       let { blockhash } = await connection.getRecentBlockhash("confirmed");

//       let batch = file[i];
//       await Promise.all(
//         batch.map((p) => idk(p, new solana.PublicKey(p), blockhash))
//       );
//     }
//   });
// })();

// (async () => {
//   connection = await authenticate();
//   console.log("authd");
//   let nonceAccounts = [];
//   let noncePubkeys = [];
//   for (let i = 0; i < BATCHES; i++) {
//     let batch = [];
//     for (let y = 0; y < 30; y++) {
//       let keypair = solana.Keypair.generate();
//       // console.log(`nonce account ${i}: ${keypair.publicKey.toBase58()}`);
//       nonceAccounts.push(keypair);
//       batch.push(keypair.publicKey.toBase58());
//       // (async () => {
//       await sleep(1000);
//       makeNonceAccount({ nonceAccount: keypair });
//       // })();
//     }
//     noncePubkeys.push(batch);
//   }
//   await sleep(3000);

//   // await Promise.all(
//   //   nonceAccounts.map((nonceAccount) => {
//   //     // await sleep(500);
//   //     (async () => {
//   //       await sleep(1000);
//   //       makeNonceAccount({ nonceAccount });
//   //     })();
//   //   })
//   // );
//   console.log("noncePubkeys: ", noncePubkeys);
//   fs.writeFile(
//     "noncePubkeys3.txt",
//     JSON.stringify(noncePubkeys),
//     function (err) {
//       if (err) return console.log(err);
//     }
//   );
//   fs.writeFile(
//     "nonceKeypairs3.txt",
//     JSON.stringify(nonceAccounts),
//     function (err) {
//       if (err) return console.log(err);
//     }
//   );
//   console.log("nonceAccounts...", nonceAccounts);
// })();
