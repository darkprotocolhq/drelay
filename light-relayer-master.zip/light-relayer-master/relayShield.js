require("dotenv").config();
const solana = require("@solana/web3.js");
const token = require("@solana/spl-token");
var ffjavascript = require("ffjavascript");
const bs58 = require("bs58");
const { wtns, groth16, zKey } = require("snarkjs");
const { U64, I64 } = require("n64");
const { authenticate } = require("./auth");
const { unstringifyBigInts, leBuff2int, leInt2Buff, beInt2Buff } =
  ffjavascript.utils;
const {
  sendSignedTransaction,
  recoverAndSignOfflineTransactions,
  recoverAndSignOfflineTransaction,
} = require("./send");
const {
  PRIVATE_KEY,
  MERKLE_TREE_PDA_PUBKEY,
  PROGRAM_ID,
  TOKEN_POOL_PUBKEY,
  RELAYER_TOKEN_PUBKEY,
  RPC_URL,
  FEE,
} = process.env;

const FIELD_SIZE = unstringifyBigInts(
  "21888242871839275222246405745257275088548364400416034343698204186575808495617"
);
/// Set addresses
const merkleTreePubkey = new solana.PublicKey(MERKLE_TREE_PDA_PUBKEY);
const merkleTreeTokenPubkey = new solana.PublicKey(TOKEN_POOL_PUBKEY);

const programId = new solana.PublicKey(PROGRAM_ID);

const decodedPrivkey = (privkeyBytes) => {
  const decodedPrivkey = new Uint8Array(64);
  privkeyBytes
    .split(",")
    .map((b, index) => (decodedPrivkey[index] = parseInt(b)));
  return decodedPrivkey;
};
/// Set signer
const signerPrivkey = decodedPrivkey(PRIVATE_KEY);
var signerKeypair = solana.Keypair.fromSecretKey(signerPrivkey);
const signerPubkey = signerKeypair.publicKey;
console.log("signerPubkey: ", signerPubkey.toBase58());

/// Set Connection
var connection;

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

async function getNodeConnection() {
  connection = await authenticate();
  console.log("Connection to cluster established");
}

async function relayShield(req, res) {
  try {
    await getNodeConnection();
    const { txPool, txLast } = req.body;

    console.time("sig 1");
    let txPoolRecovered = recoverAndSignOfflineTransactions({
      transactionsAndFeePayerSignatures: txPool,
      nonceAuthorityKeypair: signerKeypair,
    });
    console.timeEnd("sig 1");

    console.time("send 1");
    if (txPoolRecovered) {
      await Promise.all(
        txPoolRecovered.map((signedTransaction, i) =>
          sendSignedTransaction({
            signedTransaction,
            connection,
            i,
          })
        )
      );
    } else {
      throw new Error("Unable to sign all Pool transactions");
    }
    console.timeEnd("send 1");

    console.time("sig 2");
    let recoverTx = recoverAndSignOfflineTransaction({
      messageAndFeePayerSignature: txLast,
      nonceAuthorityKeypair: signerKeypair,
    });
    console.time("sig 2");

    console.time("reconnecting");
    await getNodeConnection();
    console.timeEnd("reconnecting");

    console.time("send 2");
    if (recoverTx) {
      await sendSignedTransaction({
        signedTransaction: recoverTx,
        connection,
      });
    } else {
      throw new Error("Unable to sign txLast");
    }
    console.timeEnd("send 2");

    console.log("success");
    success = true;
    return true;
  } catch (e) {
    console.log("relay failed", e);
    return false;
  }
}

module.exports = { relayShield };
