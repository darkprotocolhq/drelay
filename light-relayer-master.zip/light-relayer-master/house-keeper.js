const IORedis = require("ioredis");
const { Queue, Worker } = require("bullmq");
require("dotenv").config();
const nacl = require("tweetnacl");
const { BATCH_ARRAY, BATCH_ARRAY_DEV } = require("./nonce-pubkeys");

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const client = require("twilio")(accountSid, authToken);
const newNonce = () => nacl.randomBytes(nacl.box.nonceLength);
const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

const connection = new IORedis(
  Number(process.env.DB_PORT),
  process.env.HOSTNAME,
  {
    username: "default",
    password: process.env.PASSWORD,
    tls: {},
  }
);

const s = 1000;
const minute = 60 * s;
const hour = 60 * minute;
const shieldQueue = new Queue("shielding", { connection }); // Specify Redis connection using object
const unshieldQueue = new Queue("unshielding", { connection }); // Specify Redis connection using object
const nonceQueue = new Queue("nonce", { connection }); // append only store

function getBatchAndLockArray() {
  if (!process.env.ENVIRONMENT) {
    throw new Error("no ENVIRONMENT set", process.env.ENVIRONMENT);
  }
  let batchArray;
  if (process.env.ENVIRONMENT === "PROD") {
    batchArray = BATCH_ARRAY; // BATCH_ARRAY
  } else if (process.env.ENVIRONMENT === "DEV") {
    batchArray = BATCH_ARRAY_DEV; // BATCH_ARRAY_DEV
  }
  let lockArray = Array(batchArray.length).fill(0);
  return { batchArray, lockArray };
}

const { batchArray } = getBatchAndLockArray();
const batchLength = batchArray.length;

async function getJobList() {
  let activeUnshieldJobs = await unshieldQueue.getActive();
  let activeShieldJobs = await shieldQueue.getActive();
  let waitingUnshieldJobs = await unshieldQueue.getWaiting();
  let waitingShieldJobs = await shieldQueue.getWaiting();

  let activeJobs = [
    activeUnshieldJobs,
    activeShieldJobs,
    waitingUnshieldJobs,
    waitingShieldJobs,
  ].flat();

  return {
    total: activeJobs,
    activeUnshield: activeUnshieldJobs,
    activeShield: activeShieldJobs,
    waitingUnshield: waitingUnshieldJobs,
    waitingShield: waitingShieldJobs,
  };
}
async function cleanNonceJob(job, instant = false) {
  if (Date.now() - job.timestamp >= hour || instant) {
    try {
      await job.moveToFailed("timeout nonce wipe", job.token);
    } catch (e) {
      console.log(e);
    }
    try {
      await nonceQueue.remove(job.id);
    } catch (e) {
      console.log(e);
    }
  }
}
async function sendTwilio(message) {
  try {
    console.log("sending notification to TO1");
    client.messages
      .create({
        from: `whatsapp:${process.env.FROM}`,
        body: message,
        to: `whatsapp:${process.env.TO1}`,
      })
      .then((message) => console.log(message.sid));
  } catch (e) {
    console.log(e);
  }

  try {
    console.log("sending notification to TO2");
    client.messages
      .create({
        from: `whatsapp:${process.env.FROM}`,
        body: message,
        to: `whatsapp:${process.env.TO2}`,
      })
      .then((message) => console.log(message.sid));
  } catch (e) {
    console.log(e);
  }
}

// REPORT ON CONCURRENCY -> TWILIO
var concurrent = 0;
(async () => {
  while (1) {
    try {
      let {
        total: activeJobs,
        activeUnshield,
        activeShield,
        waitingUnshield,
        waitingShield,
      } = await getJobList();
      if (activeJobs.length > 1 && activeJobs.length > concurrent) {
        concurrent = activeJobs.length;
        let message = `${activeJobs.length} concurrent jobs!\n(U-A: ${activeUnshield.length}; U-W: ${waitingUnshield.length}; S-A: ${activeShield.length}; S-W: ${waitingShield.length})`;
        await sendTwilio(message);
        // await sleep(5 * minute);
      } else {
        (async () => {
          if (activeJobs.length === 0) {
            await sleep(30 * s);
          }
          concurrent = activeJobs.length;
        })();
      }
    } catch (e) {
      console.log(e);
    }
    await sleep(10 * s);
  }
})();

// REPORT HOURLY JOBS DONE
let lastNumber = 0;
(async () => {
  while (1) {
    let cS = shieldQueue.getCompleted();
    let cU = unshieldQueue.getCompleted();
    let c = [cU, cS].flat();
    let diff = c.length - lastNumber;
    let message = `last hour: ${diff} successful users`;
    await sendTwilio(message);
    lastNumber = c.length;
    await sleep(hour);
  }
})();

/// REPORT NONCE QUEUE UNDERFLOW (30s)
(async () => {
  while (1) {
    try {
      let waiting = await nonceQueue.getWaiting();
      let active = await nonceQueue.getActive();
      console.log(
        "WAITING NONCES:",
        waiting.map((n) => n.data.index)
      );
      console.log(
        "ACTIVE NONCES:",
        active.map((n) => n.data.index)
      );

      if (waiting.length + active.length < batchLength - 1) {
        // WARN
        let message = `Warning: only ${
          waiting.length + active.length
        } nonces exist!`;
        await sendTwilio(message);
        await sleep(5 * minute);
      }
    } catch (e) {
      console.log(e);
    }
    await sleep(0.5 * minute);
  }
})();

/**
 * 1. remove timed-out noncejobs (1 hour timeout)
 * 2. remove nonce jobs with indices > max len-1
 * 3. replace nonce jobs with undefined indices with leftover indices
 * 4. fill up nonce jobs with available indices if jobs < max len
 * run every 5s
 */
(async () => {
  while (1) {
    try {
      let waiting = await nonceQueue.getWaiting();
      let active = await nonceQueue.getActive();
      // if no traffic, remove all timed-out active nonce jobs.
      let { total } = await getJobList();
      if (total.length === 0) {
        await Promise.all(active.map((j) => cleanNonceJob(j)));
        console.log(
          "active noncejobs : ",
          (await nonceQueue.getActive()).length
        );
      }

      let a = Array(batchLength)
        .fill(0)
        .map((_, i) => i);

      waiting.map((n) => {
        if (n.data.index > a.length - 1) {
          (async () => {
            await nonceQueue.remove(n.id);
            console.log("removed nj >> index range |", n.data.index);
          })();
        }

        if (!n.data.index && n.data.index !== 0) {
          (async () => {
            // remove and add new with index thats not in the queues yet
            await nonceQueue.remove(n.id);
            console.log("removed job with i: undefined");

            let active2 = await nonceQueue.getActive();
            let waiting2 = await nonceQueue.getWaiting();
            let index = a.find(
              (i) =>
                ![active2, waiting2]
                  .flat()
                  .map((n) => n.data.index)
                  .includes(i)
            );

            if (index || index === 0) {
              console.log("found available index:", index);
              let nonce = String(newNonce());

              let addedJob = await nonceQueue.add(nonce, {
                index: index,
                timeStamp: Date.now(),
              });
              console.log(
                "updated nj >> undef -> index | ",
                addedJob.data.index
              );
            }
          })();
        }
      });
      // if waiting job are less, find the index that's not in the queues and add the job'
      if (waiting.length < batchLength) {
        let waitingNow = await nonceQueue.getWaiting();
        let activeNow = await nonceQueue.getActive();
        let indices = a.filter(
          (i) =>
            ![waitingNow, activeNow]
              .flat()
              .map((n) => n.data.index)
              .includes(i)
        );

        for (index of indices) {
          if (index === 0 || index) {
            (async () => {
              console.log("< 33 ! -> adding index:", index);
              let nonce = String(newNonce());
              let addedJob = await nonceQueue.add(nonce, {
                index: index,
                timeStamp: Date.now(),
              });
            })();
          }
        }
      }
      let waiting3 = await nonceQueue.getWaiting();
      let active3 = await nonceQueue.getActive();

      // find jobs with duplicates
      let found = [];
      waiting3.map((n) => {
        try {
          let x = [waiting3, active3]
            .flat()
            .filter((n2) => n2.data.index == n.data.index);
          if (x.length > 1) {
            x.forEach(function (value) {
              if (!found.some((el) => el.data.index === value.data.index))
                found.push(value);
            });
          }
        } catch (e) {
          console.log(e);
        }
      });
      // console.log("FILTERD:", i, "FOUND:", found);

      if (found.length > 0) {
        await Promise.all(found.map((j) => cleanNonceJob(j, true)));
        console.log("rmd duplicates", (await nonceQueue.getWaiting()).length);
      }
    } catch (e) {
      console.log(e);
    }

    await sleep(5 * s);
  }
})();

module.exports = {
  getJobList,
  sendTwilio,
  minute,
  getBatchAndLockArray,
};
