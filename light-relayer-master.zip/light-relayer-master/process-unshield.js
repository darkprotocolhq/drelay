//@ts-check
require("dotenv").config();
const solana = require("@solana/web3.js");
const token = require("@solana/spl-token");
var ffjavascript = require("ffjavascript");
// const b2noncePubkeys = [
//   "HSV5d4z8dAXLAqLabAcHJGUC2h5GLzFDfh4KTdZAvnrS",
//   "B9s4mS45gwTvosffBAQreMktottNzjU8VQXQSYgb5fi1",
//   "9k7v64dUGsqXHv7ERkKE5duK4zusYdq9Karym6ZA1D8A",
//   "Bdf6EYByNhdkVZbfVxbeuekzWL5rTbeDzh9k134cvoKu",
//   "4YyFWViiZYkY9MJvtRdncETSesS6tRHnKE4hXjL4ccia",
//   "CFN67V1A9HJRdWjua4AX4hktKXEBCH2gLRN89JU8XXwR",
//   "E1qzKLN2NhSKRt348KGjaoMuVwBFFfgHahNwt8DrkUyK",
//   "7wGdjSYiQSD7z4T8qhnVXCa5xAhRsChtmibHX4KLX7Pq",
//   "3qA8W1pEeDeDrH7YCRc5YP8xnta3DCbVsNhy4itGCUME",
//   "53S8M82MvE6JmJZTWYbkm5jFfeJ92Una5s5kb4nXq6r9",
//   "8feqYsNVEwPXtDui7sSBuCWvUGGh6iWAbWnEqHLM8rpB",
//   "5Yt1VWcfxELv7JZNXeGziFe2oS57S6RQnadg6JUuoABE",
//   "3A3kHkoz53KbHacVYtEFrKcnbPokgsWr7ujBX2cbSVvy",
//   "3wpnEfXQTocPp2L8xJR71AZPoThdAP36hSPtcqDLBFDd",
//   "EpR4tZN9uc67anRg6aW5KCApZitFF7K81rQPXWrNR1Ue",
//   "AJqcJEFh3j4Ffo1A89cXFw8LwFd14MiRsi8A8x7fWzko",
//   "5JrouviEr5qoX73Wn7MJJCuyCQQMevNWdhLuUPUmMbyb",
//   "8D7NJHtBKaHMsFxQzEpuaDP2FYhuZ89sJahEY5Wzeus4",
//   "J8gyFiA1fonX3uRqFo8fbtb45hMK4N4xjnB6jzYxrbgq",
//   "FiQ5BMqv3y5uFvLA4RmEu8QiQqsHaxvnEoFnpqtSwE87",
//   "4gvzwgfq7S6Wm4ic4y4jru94fLp7H8YaiCmGJHcLfmA3",
//   "TpWFHWF3BtnHTszNtQ3iRZ8U8t5si8NHiZTWZRwZ5ce",
//   "2RL5JGVUmuKefMtuykVj2EsjZQRtagQwLa19YNotY3ZP",
//   "68dL82YM7xvjTX8Mysazw7kcptNUxTu5m5vcdRmq5Uoj",
//   "HTK98ys9MbcM2qJ8qbeeoQ3ovw7HMAikVdoSPeDAttdD",
//   "EoJrAcfjzvAHGP1iUVuumpPNGnUj1TjZxH7NSrWQEbK",
//   "37RBZf44EPUn9WV1GAN8q52GojSdox9MYaJEjE6GLTXB",
//   "BcKnjECtz78FqYSjLqGYg7empx9mZ7F3tsgGVm4saSK1",
//   "6Q6vRFVkofwxtUKZv45a5nafonYWJjDzjGQ6eqgC3YrM",
// ];
// const b3noncePubkeys = ["JDEjQqMYCTcRG11Jxv55Jb3f23kzquVqjvffgu7BhTkj"];
const { wtns, groth16, zKey } = require("snarkjs");
const { U64 } = require("n64");
const { authenticate } = require("./auth");

const { unstringifyBigInts, leBuff2int, leInt2Buff, beInt2Buff } =
  ffjavascript.utils;
const { sendSignedTransaction, addNonceAndSign } = require("./send");
const { getLock } = require("./locked");

const {
  PRIVATE_KEY,
  MERKLE_TREE_PDA_PUBKEY,
  PROGRAM_ID,
  TOKEN_POOL_PUBKEY,
  RELAYER_TOKEN_PUBKEY,
  RPC_URL,
  FEE,
  NONCE_ACCOUNT_OWNER,
} = process.env;

const FIELD_SIZE = unstringifyBigInts(
  "21888242871839275222246405745257275088548364400416034343698204186575808495617"
);
/// Set addresses
const merkleTreePubkey = new solana.PublicKey(MERKLE_TREE_PDA_PUBKEY);
const merkleTreeTokenPubkey = new solana.PublicKey(TOKEN_POOL_PUBKEY);

const programId = new solana.PublicKey(PROGRAM_ID);

const decodedPrivkey = (privkeyBytes) => {
  const decodedPrivkey = new Uint8Array(64);
  privkeyBytes
    .split(",")
    .map((b, index) => (decodedPrivkey[index] = parseInt(b)));
  return decodedPrivkey;
};
/// Set signer
const signerPrivkey = decodedPrivkey(PRIVATE_KEY);
var signerKeypair = solana.Keypair.fromSecretKey(signerPrivkey);
const signerPubkey = signerKeypair.publicKey;
console.log("signerPubkey: ", signerPubkey.toBase58());
// Set authority signer
const nonceAuthorityPrivkey = decodedPrivkey(NONCE_ACCOUNT_OWNER);
var nonceAuthorityKeypair = solana.Keypair.fromSecretKey(nonceAuthorityPrivkey);
const nonceAuthorityPubkey = nonceAuthorityKeypair.publicKey;

/// Set Connection
var connection;

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

const createPayload = (inputBytes, proofBytes, extDataBytes) => {
  var ixData = new Uint8Array(824);
  inputBytes.map((b, index) => (ixData[index + 9] = b)); // 224
  proofBytes.map((b, index) => (ixData[index + 9 + 224] = b)); // 256
  extDataBytes.map((b, index) => (ixData[index + 9 + 224 + 256] = b)); // 208 (489..697) // adds 32 bytes for last
  return ixData;
};

async function getVerificationPda(inputBytes) {
  // derive tmp account from tx integrity hash
  var tmpAccountSeed = new Uint8Array(32);
  inputBytes.slice(64, 96).map((v, i) => {
    tmpAccountSeed[i] = v;
  });
  var verificationPdaSeed = new Uint8Array(7);
  /// Arbitrary nonce, equivalent hardcoded in program
  /// Nonce is needed because we're deriving multiple pdas from the same utxo nullifier
  var verificationPdaSeedBytes = [115, 116, 111, 114, 97, 103, 101];
  verificationPdaSeedBytes.map((v, i) => {
    verificationPdaSeed[i] = v;
  });
  let verificationPdas = await solana.PublicKey.findProgramAddress(
    [tmpAccountSeed, verificationPdaSeed],
    programId
  );

  return verificationPdas[0];
}

async function getNullifierPdas(inputBytes) {
  let x = new Uint8Array(32);
  inputBytes.slice(96, 128).map((v, i) => {
    x[i] = v;
  });
  let y = new Uint8Array(32);
  inputBytes.slice(128, 160).map((v, i) => {
    y[i] = v;
  });
  let nf_seed = new Uint8Array(2);
  let nf_seed_bytes = [110, 102];
  nf_seed_bytes.map((v, i) => {
    nf_seed[i] = v;
  });

  const nullifier0 = await solana.PublicKey.findProgramAddress(
    [x, nf_seed],
    programId
  );
  const nullifier1 = await solana.PublicKey.findProgramAddress(
    [y, nf_seed],
    programId
  );
  return { nullifier0: nullifier0[0], nullifier1: nullifier1[0] };
}

async function getLeavesPda(inputBytes) {
  let x = new Uint8Array(32);
  inputBytes.slice(96, 128).map((v, i) => {
    x[i] = v;
  });
  var leavesPdaSeed = new Uint8Array(6);
  let leavesPdaSeed_bytes = [108, 101, 97, 118, 101, 115];
  leavesPdaSeed_bytes.map((v, i) => {
    leavesPdaSeed[i] = v;
  });
  let leavesPda = await solana.PublicKey.findProgramAddress(
    [x, leavesPdaSeed],
    programId
  );
  return leavesPda[0];
}

async function getAuthorityPubkey() {
  let authoritySeed = Uint8Array.from(programId.toBytes());
  let [authorityPubkey, bumpSeed] = await solana.PublicKey.findProgramAddress(
    [authoritySeed],
    programId
  );
  return authorityPubkey;
}

const getRecipientTokenPda = (bytes) => {
  return new solana.PublicKey(bytes);
};

async function getNodeConnection() {
  connection = await authenticate();
  // const version = await connection.getVersion();
  console.log("Connection to cluster established");
}

async function makeTransactionPool({
  txs,
  ixPerTx,
  keys,
  ixDataLength = 9,
  signerPubkey,
}) {
  var txPool = [];
  let txCount = 0;
  for (let i = 0; i < txs; i++) {
    let tx = new solana.Transaction();
    tx.feePayer = signerPubkey;

    //j is the number of ix in one tx.
    for (let j = 0; j < ixPerTx && j + i < txs; j++) {
      addIx({ tx, ixDataLength, randU8: txCount, keys });
    }
    txCount += 1;
    // one less than batch since i already increases by 1
    i += ixPerTx - 1;
    txPool.push({ transaction: tx, signers: [] });
  }
  return txPool;
}

async function makeTransactionPoolMirror({
  txs,
  ixPerTx,
  keys,
  ixDataLength = 9,
  signerPubkey,
  base = 50,
}) {
  var txPool = [];
  let txCount = base;
  for (let i = 0; i < txs; i++) {
    let tx = new solana.Transaction();
    tx.feePayer = signerPubkey;

    //j is the number of ix in one tx.
    for (let j = 0; j < ixPerTx && j + i < txs; j++) {
      addIx({ tx, ixDataLength, randU8: txCount, keys });
    }
    txCount += 1;
    // one less than batch since i already increases by 1
    i += ixPerTx - 1;
    txPool.push({ transaction: tx, signers: [] });
  }
  return txPool;
}

const addIx = ({
  tx,
  payload = null,
  keys,
  ixDataLength = null,
  randU8 = null,
}) => {
  let ixData;
  if (payload === null) {
    ixData = new Uint8Array(ixDataLength);
    ixData[0] = randU8;
  } else {
    ixData = payload;
  }

  tx.add(
    new solana.TransactionInstruction({
      programId: programId,
      keys: [
        {
          pubkey: keys[0],
          isSigner: true,
          isWritable: false,
        },
        keys.slice(1).map((key) => {
          if (
            key == token.TOKEN_PROGRAM_ID ||
            key == solana.SystemProgram.programId ||
            key == solana.SYSVAR_RENT_PUBKEY
          ) {
            return {
              pubkey: key,
              isSigner: false,
              isWritable: false,
            };
          } else {
            return {
              pubkey: key,
              isSigner: false,
              isWritable: true,
            };
          }
        }),
      ].flat(),
      data: Buffer.from(ixData),
    })
  );
};

async function relayTransaction({
  inputBytes,
  proofBytes,
  extDataBytes,
  action,
  batch,
  batchMirror,
  job,
}) {
  /// Set Pdas
  const { nullifier0, nullifier1 } = await getNullifierPdas(inputBytes);
  const verificationPda = await getVerificationPda(inputBytes);
  const leavesPda = await getLeavesPda(inputBytes);
  const authorityPubkey = await getAuthorityPubkey();
  const recipientSolAddress = getRecipientTokenPda(extDataBytes.slice(0, 32));

  /// Create new token account if none supplied
  var relayerTokenPubkey = new solana.PublicKey(RELAYER_TOKEN_PUBKEY);

  /// Sends all data to the verification account; on-chain as "init_hash_bytes"
  let tx = new solana.Transaction();
  tx.feePayer = signerPubkey;
  let ixData = createPayload(inputBytes, proofBytes, extDataBytes);

  addIx({
    tx: tx,
    payload: ixData,
    keys: [
      signerPubkey,
      verificationPda,
      solana.SystemProgram.programId,
      solana.SYSVAR_RENT_PUBKEY,
    ],
  });

  /// Checks nullifier and root
  addIx({
    tx: tx,
    ixDataLength: 1,
    randU8: 0,
    keys: [signerPubkey, verificationPda, merkleTreePubkey],
  });

  let txPool1 = await makeTransactionPool({
    txs: 1499,
    ixPerTx: 53, // 65
    keys: [signerPubkey, verificationPda, merkleTreePubkey],
    signerPubkey: signerPubkey,
  });

  ///// FALLOVER

  let txPoolMirror = await makeTransactionPoolMirror({
    txs: 1499,
    ixPerTx: 53, // 65
    keys: [signerPubkey, verificationPda, merkleTreePubkey],
    signerPubkey: signerPubkey,
  });

  /// Executes the token transfer
  let txLast = new solana.Transaction();

  txLast.feePayer = signerPubkey;

  // console.log("act: ", action);
  if (action === "TRANSFER") {
    addIx({
      tx: txLast,
      ixDataLength: 9,
      randU8: 0,
      keys: [
        signerPubkey,
        verificationPda,
        leavesPda,
        nullifier0,
        nullifier1,
        merkleTreePubkey,
        merkleTreeTokenPubkey,
        solana.SystemProgram.programId,
        token.TOKEN_PROGRAM_ID,
        solana.SYSVAR_RENT_PUBKEY,
        authorityPubkey,
        relayerTokenPubkey,
      ],
    });
  }
  if (action === "WITHDRAWAL") {
    addIx({
      tx: txLast,
      ixDataLength: 9,
      randU8: 0,
      keys: [
        signerPubkey,
        verificationPda,
        leavesPda,
        nullifier0,
        nullifier1,
        merkleTreePubkey,
        merkleTreeTokenPubkey,
        solana.SystemProgram.programId,
        token.TOKEN_PROGRAM_ID,
        solana.SYSVAR_RENT_PUBKEY,
        authorityPubkey,
        recipientSolAddress,
        relayerTokenPubkey, // Sol pubkey
      ],
    });
  }

  try {
    await getNodeConnection();
  } catch (e) {
    console.log(e);
  }
  try {
    console.time("1");
    var blockhash = (await connection.getLatestBlockhash("confirmed"))
      .blockhash;
    console.log("blockhash", blockhash);

    tx.recentBlockhash = blockhash;
    tx.feePayer = signerPubkey;
    tx.sign(...[signerKeypair]);
    if (tx) {
      await sendSignedTransaction({
        signedTransaction: tx,
        connection,
        id: job.id,
      });
    } else {
      throw new Error("Unable to sign init transaction");
    }
    console.timeEnd("1");

    const authorizedPubkey = new solana.PublicKey(
      "7cmupLZLnkHbecJRSjVKh71iUUY3izyncmx1rbS8jkYa"
    );
    const signedTxPool = [];
    await Promise.all(
      txPool1.map((tx, index) =>
        addNonceAndSign({
          noncePubkey: new solana.PublicKey(batch[index]),
          connection,
          tx: tx.transaction,
          txToSign: signedTxPool,
          authorizedPubkey,
          signerPubkey,
          payer: signerKeypair,
          signers: [nonceAuthorityKeypair],
        })
      )
    );

    ///// ADDING FALLOVER

    const signedTxPoolMirrorRaw = [];
    await Promise.all(
      txPoolMirror.map((tx, index) =>
        addNonceAndSign({
          noncePubkey: new solana.PublicKey(batchMirror[index]),
          connection,
          tx: tx.transaction,
          txToSign: signedTxPoolMirrorRaw,
          authorizedPubkey,
          signerPubkey,
          payer: signerKeypair,
          signers: [nonceAuthorityKeypair],
        })
      )
    );

    // split filter
    // TODO - replace 25 with dynamic value
    let signedTxPoolMirror = signedTxPoolMirrorRaw.filter(
      (tx) => tx.instructions.length > 25
    );
    // console.log("mirrorPoolRecovered", signedTxPoolMirror);
    // find the recovered tx with 15 ix
    let signedTxPoolMirrorRecovered15 = signedTxPoolMirrorRaw.filter(
      (tx) => tx.instructions.length < 25
    )[0];
    // console.log("signedTxPoolMirrorRecovered15", signedTxPoolMirrorRecovered15);

    // console.log("BATCH:", batch.length);
    // add nonce, sign and send
    const noncePubkey = new solana.PublicKey(batch[batch.length - 1]);
    txLast.feePayer = signerPubkey;
    let accountInfo = await connection.getAccountInfo(noncePubkey);
    let nonceAccount = solana.NonceAccount.fromAccountData(accountInfo.data);
    txLast.nonceInfo = {
      nonce: nonceAccount.nonce,
      nonceInstruction: solana.SystemProgram.nonceAdvance({
        noncePubkey,
        authorizedPubkey,
      }),
    };
    txLast.sign(...[signerKeypair].concat([nonceAuthorityKeypair]));

    console.time("send 1");
    if (signedTxPool) {
      try {
        await Promise.all(
          signedTxPool.map((signedTransaction, i) =>
            sendSignedTransaction({
              signedTransaction,
              connection,
              i,
              id: job.id,
            })
          )
        );
      } catch (err) {
        console.log(`failed bc locked! job: ${job.id}`);
        console.log("TXPOOLMIRROR hashed", txPoolMirror.length);
        console.log("tmp account ?", signedTxPoolMirror[0]);
        try {
          console.log(
            "tmp account0 ?",
            signedTxPoolMirror[0].instructions[0].keys[0].pubkey.toBase58()
          );
          console.log(
            "tmp account1 ?",
            signedTxPoolMirror[0].instructions[0].keys[1].pubkey.toBase58()
          );
          console.log(
            "tmp account2 ?",
            signedTxPoolMirror[0].instructions[0].keys[2].pubkey.toBase58()
          );
        } catch (e) {}
        console.log(
          "KEYS1",
          // signedTxPoolMirror[0].instructions[0].keys[1],
          "KEYS1pk"
          // signedTxPoolMirror[0].instructions[0].keys[1].pubkey
        );

        let { txArrayIndex } = await getLock({
          merkleTreePubkey: new solana.PublicKey(MERKLE_TREE_PDA_PUBKEY),
          txArray: signedTxPoolMirror,
          connection,
          id: job.id,
          signerPubkey: verificationPda.toBase58(),
        });
        console.log("txArrayIndex", txArrayIndex);
        if (!txArrayIndex) {
          return new Error(`getlock: txArrayIndex is ${txArrayIndex}`);
        }

        /// get ix_index from last working tx
        let state_after_30_secs = await connection.getAccountInfo(
          new solana.PublicKey(MERKLE_TREE_PDA_PUBKEY)
        );
        let ix_index = Number(U64(state_after_30_secs.data.slice(212, 220)));

        console.log("ixindex..", ix_index);
        console.log(
          "Formula: start slice: ",
          Number(signedTxPoolMirror.length) - (1484 - ix_index) / 53
        );
        console.log("slice end: ", signedTxPoolMirror.length);
        let mirrorPool = signedTxPoolMirror.slice(
          Number(signedTxPoolMirror.length) - 6
          // Number(mirrorPoolRecovered.length) - (1484 - ix_index) / 53
        );
        console.log("mirrorpool", mirrorPool.length);
        console.log("job.id", job.id);
        try {
          await Promise.all(
            mirrorPool.map((signedTransaction, i) =>
              sendSignedTransaction({
                signedTransaction,
                connection,
                i,
                id: job.id,
              })
            )
          );
          console.log(`done sending mirror pool...${job.id}`);
        } catch (e) {
          console.log(
            `failed mirror pool! (expect last tx now....) job: ${job.id}, e -${e}`
          );
        }
        try {
          await sendSignedTransaction({
            signedTransaction: signedTxPoolMirrorRecovered15,
            connection,
            i: signedTxPoolMirrorRaw.length - 1,
            id: job.id,
          });
        } catch {
          console.log("cannot execute last 15 ix, skip to last tx");
        }
      }
    } else {
      throw new Error("Unable to send all Pool transactions");
    }
    console.timeEnd("send 1");

    console.time("reconnecting");
    await getNodeConnection();
    console.timeEnd("reconnecting");

    console.time("send 2");
    if (txLast) {
      await sendSignedTransaction({
        signedTransaction: txLast,
        connection,
        id: job.id,
      });
    } else {
      throw new Error("Unable to sign txLast");
    }
    console.timeEnd("send 2");
  } catch (error) {
    console.log(error);
    return false;
  }
}

async function checkParams(req, vKey) {
  let proof = {
    pi_a: [
      leBuff2int(Buffer.from(req.data.proof.slice(0, 32))).toString(),
      leBuff2int(Buffer.from(req.data.proof.slice(32, 64))).toString(),
      "1",
    ],
    pi_b: [
      [
        leBuff2int(Buffer.from(req.data.proof.slice(64, 96))).toString(),
        leBuff2int(Buffer.from(req.data.proof.slice(96, 128))).toString(),
      ],
      [
        leBuff2int(Buffer.from(req.data.proof.slice(128, 160))).toString(),
        leBuff2int(Buffer.from(req.data.proof.slice(160, 192))).toString(),
      ],
      ["1", "0"],
    ],
    pi_c: [
      leBuff2int(Buffer.from(req.data.proof.slice(192, 224))).toString(),
      leBuff2int(Buffer.from(req.data.proof.slice(224, 256))).toString(),
      "1",
    ],
    protocol: "groth16",
    curve: "bn128",
  };

  let publicSignals = [];
  for (var i = 0; i < req.data.input.length; i += 32) {
    publicSignals.push(
      leBuff2int(Buffer.from(req.data.input.slice(i, i + 32))).toString()
    );
  }

  const res_verify = await groth16.verify(vKey, publicSignals, proof);
  if (!res_verify) {
    console.log("Proof verification failed.");
    throw "Proof verification failed.";
  }

  // fee is the same as in relayer env
  // let client_fee = U64();
  // client_fee.readLE(req.data.extData.slice(32 + 32 + 8, 32 + 32 + 8 + 32), 0);

  // if (client_fee != unstringifyBigInts(FEE)) {
  //   // console.log(`client_fee ${client_fee} != ${FEE}`);
  //   // throw `client_fee ${client_fee} != ${FEE}`;
  // }
  // withdrawal amount is greater or equal than fee
  let withdrawal_amount = FIELD_SIZE - unstringifyBigInts(publicSignals[1]);

  // if (withdrawal_amount < unstringifyBigInts(FEE)) {
  //   console.log(`Withdrawal amount ${withdrawal_amount} < ${FEE}`);
  //   throw `Withdrawal amount ${withdrawal_amount} < ${FEE}`;
  // }
  // do nullifiers exist? probably makes sense to fetch and store nullifiers before
  // does root exist?
  // save roots also before
  return true;
}

// Todo: add input nullifier, root, tx integrityhash validation
async function processUnshield(job, vKey, batch, batchMirror) {
  try {
    await getNodeConnection();
    try {
      // console.log("SWEN:", job);
      await checkParams(job, vKey);
    } catch (e) {
      console.log("Should return falsefailed response to caller, e:", e);
      throw new Error();
    }
    // batchMirror.map((pubkeyM) => {
    //   batch.map((pubkeyB) => {
    //     if (new solana.PublicKey(pubkeyM).toBase58() === new solana.PublicKey(pubkeyB).toBase58()) {
    //       console.log("job.id ", new solana.PublicKey(pubkeyM).toBase58(), " === ",new solana.PublicKey(pubkeyB).toBase58() );
    //       throw new Error("Nonce account batches overlap.");
    //     }
    //   })
    // })
    console.log("Starting relayTransaction");
    await relayTransaction({
      inputBytes: job.data.input,
      proofBytes: job.data.proof,
      extDataBytes: job.data.extData,
      action: job.data.action,
      batch,
      batchMirror,
      job,
    });

    console.log("success");
    return true;
  } catch (e) {
    console.log("relay failed", e);
    return false;
  }
}

module.exports = { processUnshield, checkParams };
