require("dotenv").config();
const solana = require("@solana/web3.js");
const token = require("@solana/spl-token");
var ffjavascript = require("ffjavascript");

const { wtns, groth16, zKey } = require("snarkjs");
const { U64, I64 } = require("n64");
const { authenticate } = require("./auth");
const { unstringifyBigInts, leBuff2int, leInt2Buff, beInt2Buff } =
  ffjavascript.utils;
const { sendSignedTransaction, signTransactions } = require("./send");
const {
  PRIVATE_KEY,
  MERKLE_TREE_PDA_PUBKEY,
  PROGRAM_ID,
  TOKEN_POOL_PUBKEY,
  RELAYER_TOKEN_PUBKEY,
  RPC_URL,
  FEE,
} = process.env;

const decodedPrivkey = (privkeyBytes) => {
  const decodedPrivkey = new Uint8Array(64);
  privkeyBytes
    .split(",")
    .map((b, index) => (decodedPrivkey[index] = parseInt(b)));
  return decodedPrivkey;
};
/// Set signer
const signerPrivkey = decodedPrivkey(PRIVATE_KEY);
var signerKeypair = solana.Keypair.fromSecretKey(signerPrivkey);
const signerPubkey = signerKeypair.publicKey;
console.log("signerPubkey: ", signerPubkey.toBase58());

/// Set Connection
var connection = new solana.Connection(
  solana.clusterApiUrl("mainnet-beta"),
  "confirmed"
);

(async () => {
  let tx = new solana.Transaction();
  tx.feePayer = signerPubkey;
  let { blockhash } = await connection.getLatestBlockhash("max");
  tx.recentBlockhash = blockhash;
  console.log(tx.recentBlockhash);
  tx.add(
    token.createSyncNativeInstruction(
      new solana.PublicKey(TOKEN_POOL_PUBKEY),
      token.TOKEN_PROGRAM_ID
    )
  );
  const txHash = await connection.sendTransaction(tx, [signerKeypair]);
  console.log("txHash", txHash);
  console.log(
    `confirmed: ${await connection.confirmTransaction(txHash, "finalized")}`
  );
})();
