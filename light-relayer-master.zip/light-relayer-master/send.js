//@ts-check
require("dotenv").config();
const bs58 = require("bs58");
// const solana = require("@solana/web3.js");
const nacl = require("tweetnacl");
const solana = require("@solana/web3.js");

var recentBlockhash = "";
var lastSlot = 0;
var recentBlockhashTime = 0;

// Decodes a private key
// const decodedPrivkey = (privkeyBytes) => {
//   const decodedPrivkey = new Uint8Array(64);
//   privkeyBytes
//     .split(",")
//     .map((b, index) => (decodedPrivkey[index] = parseInt(b)));
//   return decodedPrivkey;
// };

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));
const getUnixTs = () => {
  return new Date().getTime() / 1000;
};

async function serializeTx({
  tx,
  noncePubkey,
  connection,
  signerPubkey,
  authorizedPubkey,
  signerKeypair,
  txPoolDataNeedToSign,
}) {
  let accountInfo = await connection.getAccountInfo(noncePubkey);
  let nonceAccount = solana.NonceAccount.fromAccountData(accountInfo.data);
  tx.feePayer = signerPubkey;
  tx.nonceInfo = {
    nonce: nonceAccount.nonce,
    // nonce advance must be the first insturction
    nonceInstruction: solana.SystemProgram.nonceAdvance({
      noncePubkey,
      authorizedPubkey,
    }),
  };
  let msg = tx.serializeMessage();
  let feePayerSignature = nacl.sign.detached(msg, signerKeypair.secretKey);
  return txPoolDataNeedToSign.push({
    message: msg,
    feePayerSignature: feePayerSignature,
  });
}

async function addNonceAndSign({
  tx,
  connection,
  noncePubkey,
  signerPubkey,
  txToSign,
  authorizedPubkey,
  payer,
  signers = [],
}) {
  let accountInfo = await connection.getAccountInfo(noncePubkey);
  let nonceAccount = solana.NonceAccount.fromAccountData(accountInfo.data);
  tx.feePayer = signerPubkey;
  tx.nonceInfo = {
    nonce: nonceAccount.nonce,
    // nonce advance must be the first insturction
    nonceInstruction: solana.SystemProgram.nonceAdvance({
      noncePubkey,
      authorizedPubkey,
    }),
  };
  tx.setSigners(payer.publicKey, ...signers.map((s) => s.publicKey));
  tx.sign(...[payer].concat(signers));
  return txToSign.push(tx);
}

function recoverAndSignOfflineTransaction({
  messageAndFeePayerSignature,
  nonceAuthorityKeypair,
}) {
  // Parse from buffer/Object
  // console.log("messageAndFeePayerSignature", messageAndFeePayerSignature);
  // console.log("nonceAuthorityKeypair", nonceAuthorityKeypair);
  let buffer = Buffer.from(
    Object.values(messageAndFeePayerSignature.feePayerSignature)
  );
  let feePayerSignature = new Uint8Array(buffer.length);
  feePayerSignature.set(buffer);
  console.log(feePayerSignature);

  let message = new Uint8Array(messageAndFeePayerSignature.message.data.length);
  message.set(Buffer.from(messageAndFeePayerSignature.message.data));

  // Sign
  let nonceAuthoritySignature = nacl.sign.detached(
    message,
    nonceAuthorityKeypair.secretKey
  );
  // Recover with signatures
  let recoverTx = solana.Transaction.populate(solana.Message.from(message), [
    bs58.encode(feePayerSignature),
    bs58.encode(nonceAuthoritySignature),
  ]);
  // console.log("recoverTx: ");
  return recoverTx;
}

function recoverAndSignOfflineTransactions({
  transactionsAndFeePayerSignatures,
  nonceAuthorityKeypair,
}) {
  let recoverTxs = [];
  transactionsAndFeePayerSignatures.map((txAndSig) => {
    let tx = recoverAndSignOfflineTransaction({
      messageAndFeePayerSignature: txAndSig,
      nonceAuthorityKeypair,
    });
    recoverTxs.push(tx);
  });
  return recoverTxs;
}

// const msg = (message, txid) => `${message + <Link>{txid}</Link>}`;

async function signTransactions({
  transactionsAndSigners,
  payer,
  blockhashCommitment = "confirmed",
  connection,
}) {
  if (!payer.publicKey) {
    return;
  }
  //   const now = getUnixTs();
  let blockhash;
  // Get new blockhash if stored blockhash more than 70 seconds old
  //   if (recentBlockhashTime && now < recentBlockhashTime + 70) {
  //     blockhash = recentBlockhash;
  //   } else {
  blockhash = (await connection.getLatestBlockhash(blockhashCommitment))
    .blockhash;
  //   }
  transactionsAndSigners.forEach(({ transaction, signers = [] }) => {
    transaction.recentBlockhash = blockhash;
    if (payer.publicKey) {
      transaction.setSigners(
        payer.publicKey,
        ...signers.map((s) => s.publicKey)
      );
    }
    // if (signers?.length > 0) {
    //   transaction.partialSign(...signers);
    // }
  });

  transactionsAndSigners.forEach(({ transaction, signers }) => {
    transaction.sign(...[payer].concat(signers));
  });
  return transactionsAndSigners.map((t) => t.transaction);
}

async function sendSignedTransaction({
  signedTransaction,
  connection,
  confirmLevel = "processed",
  postSendTxCallback = null,
  sendConnection = null,
  i = 0,
  id = null,
  timeout = 720000 * 2,
}) {
  // console.log("here", signedTransaction);
  // console.log("json sig", signedTransaction._json.signatures);
  // console.log("sig", signedTransaction.signatures);

  const rawTransaction = signedTransaction.serialize();
  // console.log("heres");
  // console.log(i);
  let txid = bs58.encode(signedTransaction.signatures[0].signature);
  const startTime = getUnixTs();

  if (sendConnection) {
    const promise = sendConnection.sendRawTransaction(rawTransaction);
    if (postSendTxCallback) {
      try {
        postSendTxCallback({ txid });
      } catch (e) {
        console.warn(`postSendTxCallback error ${e}`);
      }
    }
    try {
      return await promise;
    } catch (e) {
      console.error(e);
      throw new Error(`Transaction failed ${txid}`);
    }
  } else {
    txid = await connection.sendRawTransaction(rawTransaction, {
      skipPreflight: true,
    });

    if (postSendTxCallback) {
      try {
        postSendTxCallback({ txid });
      } catch (e) {
        console.log(`postSendTxCallback error ${e}`);
      }
    }
    if (!timeout) return txid;

    // console.log('Started awaiting confirmation for', txid);

    let done = false;
    (async () => {
      await sleep(400);
      while (!done && getUnixTs() - startTime < timeout) {
        console.log(
          `${txid} sendRawTransaction: job: ${id}, index: ${i}. time remaining ${
            timeout - (getUnixTs() - startTime)
          }`
        );
        connection.sendRawTransaction(rawTransaction, {
          skipPreflight: true,
        });
        await sleep(1600);
      }
    })();
    console.log(txid);

    try {
      await awaitTransactionSignatureConfirmation(
        txid,
        timeout,
        confirmLevel,
        connection,
        id,
        startTime,
        i
      );
      // done = true
    } catch (err) {
      console.log("awaitTransactionSignatureConfirmation failed", err);
      if (err.timeout) {
        throw new Error(`error - timeout ${txid}`);
      }
      // let simulateResult = null;
      // try {
      //   simulateResult = (
      //     await simulateTransaction(connection, signedTransaction, "single")
      //   ).value;
      // } catch (e) {
      //   console.log("Simulate tx failed");
      // }
      // if (simulateResult && simulateResult.err) {
      //   if (simulateResult.logs) {
      //     for (let i = simulateResult.logs.length - 1; i >= 0; --i) {
      //       const line = simulateResult.logs[i];

      //       if (line.startsWith("Program log: ")) {
      //         throw new Error(
      //           `Transaction failed: ` +
      //             line.slice("Program log: ".length) +
      //             txid
      //         );
      //       }
      //     }
      //   }
      //   throw new Error(JSON.stringify(simulateResult.err) + txid);
      // }
      console.log(err);
      throw new Error(`Transaction failed ${txid}`);
    } finally {
      done = true;
    }

    // console.log('Latency', txid, getUnixTs() - startTime);
    return txid;
  }
}

async function awaitTransactionSignatureConfirmation(
  txid,
  timeout,
  confirmLevel,
  connection,
  id,
  startTime,
  txIndex
) {
  let done = false;

  confirmLevel = "confirmed";
  const confirmLevels = ["finalized"];

  if (confirmLevel === "confirmed") {
    confirmLevels.push("confirmed");
  } else if (confirmLevel === "processed") {
    confirmLevels.push("confirmed");
    confirmLevels.push("processed");
  }
  let subscriptionId;

  const result = await new Promise((resolve, reject) => {
    (async () => {
      setTimeout(() => {
        if (done) {
          return;
        }
        done = true;
        console.log("Timed out for txid: ", txid);
        reject({ timeout: true });
      }, timeout);
      subscriptionId = undefined;
      try {
        subscriptionId = connection.onSignature(
          txid,
          (result, context) => {
            subscriptionId = undefined;
            done = true;
            if (result.err) {
              console.log(`break! reject. (job: ${id}, tx index: ${txIndex})`);
              reject(result.err);
            } else {
              // done = true;
              if (context) {
                lastSlot = context.slot;
              }
              console.log(`success: ${id}`);
              resolve(result);
            }
          },
          "processed"
        );
      } catch (e) {
        done = true;
        console.log("WS error in setup", txid, e);
      }
      let retrySleep = 800;
      while (!done) {
        // eslint-disable-next-line no-loop-func
        await sleep(retrySleep);

        (async () => {
          try {
            console.log(
              `${txid} getSignatureStatuses: ${id} time remaining ${
                timeout - (getUnixTs() - startTime)
              }`
            );
            const response = await connection.getSignatureStatuses([txid]);
            const result = response && response.value[0];
            if (!done) {
              if (!result) {
                // console.log("REST null result for", txid, result);
              } else if (result.err) {
                console.log(
                  "REST error for",
                  txid,
                  result,
                  "(would break now)"
                );

                // done = true;
                // reject(result.err);
              } else if (
                !(
                  result.confirmations ||
                  confirmLevels.includes(result.confirmationStatus)
                )
              ) {
                console.log("REST not confirmed", txid, result);
              } else {
                if (response && response.context) {
                  lastSlot = response.context.slot;
                }
                console.log("REST confirmed", txid, result);
                done = true;
                resolve(result);
              }
            }
          } catch (e) {
            if (!done) {
              console.log("REST connection error: txid", txid, e);
            }
          }
        })();
        if (retrySleep <= 3200) {
          retrySleep = retrySleep * 2;
        }
      }
    })();
  });

  if (subscriptionId) {
    connection.removeSignatureListener(subscriptionId).catch((e) => {
      console.log("WS error in cleanup", e);
    });
  }

  done = true;
  return result;
}

// async function updateRecentBlockhash(
//   blockhashTimes,
//   connection,
//   blockhashCommitment,
//   maxStoredBlockhashes = 6,
// ) {
//   const now = getUnixTs();
//   const blockhash = (await connection.getRecentBlockhash(blockhashCommitment))
//     .blockhash;
//   blockhashTimes.push({ blockhash, timestamp: now });

//   const blockhashTime =
//     blockhashTimes.length >= maxStoredBlockhashes
//       ? blockhashTimes.shift()
//       : blockhashTimes[0];

//   timeout = 90000 - (now - blockhashTime.timestamp);
//   recentBlockhash = blockhashTime.blockhash;
//   recentBlockhashTime = blockhashTime.timestamp;
// }

// /**
//  * Maintain a timeout of 30 seconds
//  * @param client
//  */
// async function maintainTimeouts() {
//   const blockhashTimes = [];
//   // eslint-disable-next-line no-constant-condition
//   while (true) {
//     await updateRecentBlockhash(blockhashTimes);
//     await sleep(10);
//   }
// }

module.exports = {
  sendSignedTransaction,
  signTransactions,
  serializeTx,
  recoverAndSignOfflineTransactions,
  recoverAndSignOfflineTransaction,
  addNonceAndSign,
};
